package rerutarudo.weaboo.fakutoriaru;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        final EditText editText = (EditText) findViewById(R.id.editText);
        Button button = (Button) findViewById(R.id.button);
        final TextView resultado = (TextView) findViewById(R.id.resultado);


        assert button != null;
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int f = Integer.parseInt(editText.getText().toString());
                int kekka = 1;


                for (f = f; f >= 2; f--) {
                    kekka = kekka * f;
                }


                resultado.setText("" + kekka);
            }
        });

    }



}
